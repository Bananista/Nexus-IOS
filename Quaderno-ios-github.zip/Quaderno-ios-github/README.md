# Quaderno iOS

Client iOS non ufficiale per il registro elettronico Mastercom, sviluppato in Swift/SwiftUI e WKWebView. Questa applicazione replica fedelmente l'architettura, il design (HTML/CSS), lo script JavaScript (`mastercom-reader.js`) e tutte le funzionalità dell'app Android originale `Quaderno`, con sincronizzazione Firebase integrata.

## Architettura del Progetto
- **UI & Design**: Utilizza la stessa interfaccia HTML/CSS (`quaderno.html`) ed esegue lo script `mastercom-reader.js` all'interno di un `WKWebView` locale.
- **Ponte nativo (`AppBridge`)**: Replica esattamente la classe `Ponte` di Kotlin, esponendo metodi JavaScript per login, salvataggio credenziali cifrate (Keychain), gestione notifiche e aggiornamento dati.
- **Database Firebase**: Configurato con il database in tempo reale Firebase per la sincronizzazione di classe, interrogazioni e riserve.
- **Persistenza & Database**: Salva la cache dei voti, compiti, note e preferenze in modo analogo alla versione Android (`UserDefaults` / Keychain).

## Requisiti di Compilazione
1. macOS con Xcode 15+
2. Dispositivo iOS 16.0+ o Simulatore
