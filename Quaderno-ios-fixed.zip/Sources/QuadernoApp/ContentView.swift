import SwiftUI
import WebKit
import QuadernoCore

struct WebViewContainer: UIViewRepresentable {
    let htmlURL: URL
    let bridge: AppBridge
    @Binding var webViewRef: WKWebView?
    
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let contentController = WKUserContentController()
        
        let scriptSource = """
        window.Ponte = {
            serveLogin: function() { window.webkit.messageHandlers.Ponte.postMessage({action: 'serveLogin'}); },
            autoInviato: function() { window.webkit.messageHandlers.Ponte.postMessage({action: 'autoInviato'}); },
            salvaCredenziali: function(u, p) { window.webkit.messageHandlers.Ponte.postMessage({action: 'salvaCredenziali', user: u, pass: p}); },
            datiPronti: function(json) { window.webkit.messageHandlers.Ponte.postMessage({action: 'datiPronti', json: json}); },
            errore: function(msg) { window.webkit.messageHandlers.Ponte.postMessage({action: 'errore', msg: msg}); },
            accedi: function(u, p) { window.webkit.messageHandlers.Ponte.postMessage({action: 'salvaCredenziali', user: u, pass: p}); },
            haCredenziali: function() { return true; },
            esci: function() { window.webkit.messageHandlers.Ponte.postMessage({action: 'esci'}); }
        };
        """
        let userScript = WKUserScript(source: scriptSource, injectionTime: .atDocumentStart, forMainFrameOnly: false)
        contentController.addUserScript(userScript)
        contentController.add(bridge, name: "Ponte")
        config.userContentController = contentController
        
        let wv = WKWebView(frame: .zero, configuration: config)
        wv.isOpaque = false
        wv.backgroundColor = UIColor(red: 11/255, green: 17/255, blue: 32/255, alpha: 1.0)
        wv.loadFileURL(htmlURL, allowingReadAccessTo: htmlURL.deletingLastPathComponent())
        
        DispatchQueue.main.async {
            webViewRef = wv
        }
        return wv
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct ContentView: View {
    @State private var webView: WKWebView?
    @State private class BridgeHolder {
        let bridge = AppBridge()
    }
    @State private var bridgeHolder = BridgeHolder()
    
    var body: some View {
        ZStack {
            Color(red: 11/255, green: 17/255, blue: 32/255)
                .ignoresSafeArea()
            
            if let htmlURL = Bundle.module.url(forResource: "quaderno", withExtension: "html", subdirectory: "Resources") {
                WebViewContainer(htmlURL: htmlURL, bridge: bridgeHolder.bridge, webViewRef: $webView)
                    .ignoresSafeArea()
            } else {
                Text("Errore: quaderno.html non trovato")
                    .foregroundColor(.white)
            }
        }
        .onAppear {
            NotificationManager.shared.requestPermission()
            
            bridgeHolder.bridge.onSalvaCredenziali = { u, p in
                KeychainManager.saveCredentials(user: u, pass: p)
            }
            bridgeHolder.bridge.onEsci = {
                KeychainManager.clear()
            }
            bridgeHolder.bridge.onDatiPronti = { json in
                let escaped = json.replacingOccurrences(of: "'", with: "\\'")
                webView?.evaluateJavascript("Quaderno.importa('\(escaped)'); Quaderno.entra();", completionHandler: nil)
            }
        }
    }
}
