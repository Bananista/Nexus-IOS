import Foundation
import Security

public class KeychainManager {
    public static func saveCredentials(user: String, pass: String) {
        let userQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "nexus_user",
            kSecValueData as String: user.data(using: .utf8)!
        ]
        let passQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "nexus_pass",
            kSecValueData as String: pass.data(using: .utf8)!
        ]
        SecItemDelete(userQuery as CFDictionary)
        SecItemDelete(passQuery as CFDictionary)
        SecItemAdd(userQuery as CFDictionary, nil)
        SecItemAdd(passQuery as CFDictionary, nil)
    }
    
    public static func getUsername() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "nexus_user",
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &result) == noErr,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    
    public static func getPassword() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "nexus_pass",
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &result) == noErr,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    
    public static func clear() {
        let q1: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: "nexus_user"]
        let q2: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: "nexus_pass"]
        SecItemDelete(q1 as CFDictionary)
        SecItemDelete(q2 as CFDictionary)
    }
}
