import Foundation

public struct MastercomService {
    public static let baseURL = "https://marconi-fc.registroelettronico.com/mastercom/index.php"
    
    public static func loadReaderScript(useCredentials: Bool, credentials: (user: String, pass: String)? = nil) -> String {
        guard let path = Bundle.module.path(forResource: "mastercom-reader", ofType: "js"),
              let readerCode = try? String(contentsOfFile: path, encoding: .utf8) else {
            return ""
        }
        
        let credsJSON: String
        if let creds = credentials {
            credsJSON = "{u: \"\(creds.user)\", p: \"\(creds.pass)\"}"
        } else if useCredentials, let u = KeychainManager.getUsername(), let p = KeychainManager.getPassword() {
            credsJSON = "{u: \"\(u)\", p: \"\(p)\"}"
        } else {
            credsJSON = "null"
        }
        
        return """
        (function(){
          if (window.__q) return; window.__q = 1;
          var CRED = \(credsJSON);
          if (!window.MastercomReader) { window.MastercomReader = (function(){
            \(readerCode)
            return MastercomReader; })(); }
          (async function(){
            try {
              const p = document.querySelector('input[type=password]');
              if (p && p.offsetParent !== null) {
                const campi = Array.prototype.filter.call(document.querySelectorAll('input'), function(i){
                  return i.offsetParent !== null && /^(text|email|tel|number|)$/i.test(i.type) && (p.compareDocumentPosition(i) & 2);
                });
                const u = campi[campi.length - 1];
                const imposta = function(el, v){
                  el.focus(); el.value = v;
                  el.dispatchEvent(new Event('input', {bubbles: true}));
                  el.dispatchEvent(new Event('change', {bubbles: true}));
                };
                if (CRED && u) {
                  imposta(u, CRED.u); imposta(p, CRED.p); Ponte.autoInviato();
                  const f = p.form;
                  let b = f && f.querySelector('button[type=submit],input[type=submit]');
                  if (!b) b = Array.prototype.find.call(document.querySelectorAll('button,input[type=button],input[type=submit],a'), function(e){
                    return /accedi|entra|login|invia/i.test((e.value || '') + ' ' + e.textContent);
                  });
                  if (b) b.click(); else if (f) f.submit();
                  return;
                }
                const salva = function(){ if (u && p.value) Ponte.salvaCredenziali(u.value, p.value); };
                document.addEventListener('click', salva, true);
                document.addEventListener('submit', salva, true);
                Ponte.serveLogin(); return;
              }
              let ok = false;
              for (let i = 0; i < 40 && !ok; i++) {
                const d = MastercomReader.diagnosi(); ok = d.current_user && d.current_key;
                if (!ok) await new Promise(function(r){ setTimeout(r, 500); });
              }
              if (!ok) { Ponte.serveLogin(); return; }
              Ponte.datiPronti(await MastercomReader.esporta());
            } catch (e) { Ponte.errore(String(e)); }
          })();
        })();
        """
    }
}
