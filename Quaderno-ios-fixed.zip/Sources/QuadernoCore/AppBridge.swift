import Foundation
import WebKit

public class AppBridge: NSObject, WKScriptMessageHandler {
    public var onServeLogin: ((Bool) -> Void)?
    public var onDatiPronti: ((String) -> Void)?
    public var onErrore: ((String) -> Void)?
    public var onSalvaCredenziali: ((String, String) -> Void)?
    public var onAutoInviato: (() -> Void)?
    public var onEsci: (() -> Void)?
    
    public func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "Ponte" else { return }
        
        if let dict = message.body as? [String: Any], let action = dict["action"] as? String {
            switch action {
            case "serveLogin":
                let fallito = dict["fallito"] as? Bool ?? false
                onServeLogin?(fallito)
            case "datiPronti":
                if let json = dict["json"] as? String { onDatiPronti?(json) }
            case "errore":
                if let msg = dict["msg"] as? String { onErrore?(msg) }
            case "salvaCredenziali":
                if let u = dict["user"] as? String, let p = dict["pass"] as? String { onSalvaCredenziali?(u, p) }
            case "autoInviato":
                onAutoInviato?()
            case "esci":
                onEsci?()
            default:
                break
            }
        }
    }
}
