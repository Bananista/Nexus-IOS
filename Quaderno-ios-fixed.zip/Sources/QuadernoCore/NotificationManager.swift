import Foundation
import UserNotifications

public class NotificationManager {
    public static let shared = NotificationManager()
    
    private init() {}
    
    public func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            print("Permesso notifiche: \(granted)")
        }
    }
    
    public func showNotification(title: String, body: String, identifier: String = UUID().uuidString) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Errore invio notifica: \(error)")
            }
        }
    }
}
