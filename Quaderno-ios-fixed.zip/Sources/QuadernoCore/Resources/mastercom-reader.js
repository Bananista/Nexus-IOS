// mastercom-reader.js (v2 - Porting iOS)
const MastercomReader = (() => {
  const BASE = "/mastercom/index.php";
  const API = "/next-api/v1/app_sito/studente_quaderno";
  const sessione = { current_user: null, current_key: null };

  (function intercetta() {
    const setH = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function (n, v) {
      if (String(n).toLowerCase() === "authorization" && v) sessione.current_key = v;
      return setH.apply(this, arguments);
    };
    const send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function (body) {
      try {
        const get = body instanceof FormData ? (k) => body.get(k)
          : typeof body === "string" ? (k) => new URLSearchParams(body).get(k) : null;
        if (get) {
          if (get("current_user")) sessione.current_user = get("current_user");
          if (get("current_key")) sessione.current_key = get("current_key");
        }
      } catch (_) {}
      return send.apply(this, arguments);
    };
  })();

  function cercaNellaPagina(nome) {
    const el = document.querySelector(`[name="${nome}"]`);
    if (el && el.value) return el.value;
    const m = document.documentElement.innerHTML.match(
      new RegExp(nome + `["']?\s*[:=,]\s*["']([^"']+)["']`));
    return m ? m[1] : null;
  }

  function leggiSessione() {
    for (const k of ["current_user", "current_key"]) {
      if (!sessione[k]) sessione[k] = cercaNellaPagina(k);
    }
    if (!sessione.current_user || !sessione.current_key) {
      throw new Error("Sessione non trovata: fai il login, poi naviga una pagina e riprova.");
    }
    return sessione;
  }

  const diagnosi = () => ({
    current_user: !!(sessione.current_user || cercaNellaPagina("current_user")),
    current_key: !!(sessione.current_key || cercaNellaPagina("current_key")),
  });

  async function pagina(statoPrincipale, extra = {}) {
    const { current_user, current_key } = leggiSessione();
    const f = new FormData();
    const campi = {
      form_stato: "studente", stato_principale: statoPrincipale, stato_secondario: "",
      permission: "", operazione: "", current_user, current_key,
      from_app: "", webview: "", header: "SI", ...extra,
    };
    for (const [k, v] of Object.entries(campi)) f.append(k, v);
    const r = await fetch(BASE, { method: "POST", credentials: "same-origin", body: f });
    if (!r.ok) throw new Error("Errore di rete: " + r.status);
    return new DOMParser().parseFromString(await r.text(), "text/html");
  }

  const pulisci = (s) => (s || "").replace(/\s+/g, " ").trim();

  function valoreNumerico(t) {
    const m = t.replace(",", ".").match(/^(\d+(?:\.\d+)?)\s*([+\-]?)$/);
    if (!m) return null;
    const base = parseFloat(m[1]);
    return m[2] === "-" ? base - 0.25 : m[2] === "+" ? base + 0.25 : base;
  }

  async function getVoti() {
    const doc = await pagina("voti", { filter_materia: "0", filter_tipo: "tutti" });
    const medie = {};
    doc.querySelectorAll(".xxxlarge").forEach((el) => {
      const etichetta = pulisci(el.nextElementSibling?.textContent);
      if (etichetta) medie[etichetta] = pulisci(el.textContent);
    });
    const voti = [...doc.querySelectorAll('tr[data-tipo="voto"]')].map((tr) => {
      const td = tr.querySelectorAll("td");
      const votoTesto = pulisci(td[0]?.querySelector("strong")?.textContent);
      const c = td[2]?.cloneNode(true);
      const materia = pulisci(c?.querySelector("strong")?.textContent);
      const docente = pulisci(c?.querySelector("i.small")?.textContent);
      const etichetta = pulisci(c?.querySelector("span.small")?.textContent);
      c?.querySelectorAll("strong,i.small,span.small,br").forEach((e) => e.remove());
      const numero = valoreNumerico(votoTesto);
      const iTag = td[1] ? td[1].querySelectorAll("i") : [];
      return {
        materiaId: tr.getAttribute("data-materia"),
        materia, docente, etichetta,
        voto: Number.isNaN(numero) ? null : numero,
        votoTesto,
        data: pulisci(iTag[0]?.textContent),
        tipo: pulisci(iTag[1]?.textContent),
        nota: pulisci(c?.textContent).replace(/^-\s*/, ""),
      };
    });
    return { medie, voti };
  }

  async function getAggiornamenti() {
    const { current_key } = leggiSessione();
    const r = await fetch(API + "/aggiornamenti", {
      credentials: "same-origin", headers: { Authorization: current_key },
    });
    if (!r.ok) throw new Error("Errore di rete: " + r.status);
    return r.json();
  }

  function leggiGiorno(td) {
    const s = td.querySelectorAll("strong");
    const c = td.cloneNode(true);
    c.querySelectorAll("strong,br").forEach((e) => e.remove());
    return {
      dataTesto: pulisci(s[0]?.textContent),
      giornoSettimana: pulisci(c.textContent),
      etichetta: pulisci(s[1]?.textContent),
    };
  }

  async function getCompiti(filtri = {}) {
    const doc = await pagina("argomenti-compiti", { filter_materia: "0", filter_tipo: "tutti", ...filtri });
    let giorno = null;
    const voci = [];
    doc.querySelectorAll("table.table tbody tr").forEach((tr) => {
      const dTd = tr.querySelector("td.center");
      if (dTd) giorno = leggiGiorno(dTd);
      const cTd = tr.querySelector("td.border-left");
      if (!cTd || !giorno) return;
      const materia = pulisci(cTd.querySelector(":scope > strong")?.textContent);
      cTd.querySelectorAll("[data-type]").forEach((el) => {
        const casella = el.querySelector("input[type=checkbox]");
        const riga = pulisci(el.querySelector("i.text-gray.small")?.textContent);
        const m = riga.match(/^\((\d{1,2}:\d{2})\s*-\s*(.+)\)$/);
        const c = el.cloneNode(true);
        c.querySelectorAll("label,span.text-gray,i,br").forEach((e) => e.remove());
        voci.push({
          ...giorno, materia,
          tipo: el.getAttribute("data-type"),
          id: (casella?.getAttribute("onchange") || "").match(/'(\d+)'/)?.[1] ?? null,
          fatto: casella ? casella.hasAttribute("checked") : null,
          inserito: pulisci(el.querySelector("span.text-gray i")?.textContent).replace(/^Inserito il\s*/i, ""),
          ora: m ? m[1] : "", docente: m ? m[2] : "",
          testo: pulisci(c.textContent),
        });
      });
    });
    return voci;
  }

  async function getAgenda(filtri = {}) {
    const doc = await pagina("agenda", { filter_tipo_agenda: "tutti", ...filtri });
    const voci = [];
    doc.querySelectorAll("table.table tbody tr").forEach((tr) => {
      const dTd = tr.querySelector("td.center");
      if (!dTd) return;
      const giorno = leggiGiorno(dTd);
      tr.querySelectorAll("[data-type]").forEach((el) => {
        const c = el.cloneNode(true);
        const orari = c.querySelector(".right-align");
        const fine = pulisci(orari?.querySelector(".text-gray")?.textContent);
        orari?.querySelector(".text-gray")?.remove();
        const inizio = pulisci(orari?.textContent);
        orari?.remove();
        const titolo = pulisci(c.querySelector("strong")?.textContent);
        const autore = pulisci(c.querySelector("i.text-gray")?.textContent).replace(/^\(|\)$/g, "");
        c.querySelectorAll("strong,i,span,br").forEach((e) => e.remove());
        voci.push({
          ...giorno, tipo: el.getAttribute("data-type"),
          inizio, fine, titolo, descrizione: pulisci(c.textContent), autore,
        });
      });
    });
    return voci;
  }

  async function getNoteDisciplinari() {
    const doc = await pagina("note-disciplinari");
    return [...doc.querySelectorAll("div.card.padding.round")].filter((e) => e.querySelector(".round-large")).map((el) => {
      const testa = el.firstElementChild;
      const forti = testa ? testa.querySelectorAll("strong") : [];
      const corpo = el.querySelector(".round-large");
      const c = corpo.cloneNode(true);
      c.querySelector(".center")?.remove();
      return {
        data: pulisci(forti[0]?.textContent),
        ora: pulisci(forti[1]?.textContent),
        docente: pulisci((testa?.textContent || "").split("→")[1]),
        titolo: pulisci(corpo.querySelector("strong")?.textContent),
        testo: pulisci(c.textContent).replace(/^[\"“”«]+|[\"“”»]+$/g, ""),
      };
    });
  }

  async function getAssenze() {
    const doc = await pagina("assenze");
    const righe = [...doc.querySelectorAll("table tbody tr")];
    const vuoto = righe.length > 0 && righe.every((tr) => /nessuna assenza/i.test(tr.textContent));
    return { vuoto, righe: vuoto ? [] : righe.map((tr) => pulisci(tr.textContent)) };
  }

  async function getMessaggi() {
    const { current_user, current_key } = leggiSessione();
    const ifr = document.createElement("iframe");
    ifr.name = "nx_msg2";
    ifr.style.cssText = "position:fixed;width:1px;height:1px;opacity:0;pointer-events:none";
    document.body.appendChild(ifr);
    const f = document.createElement("form");
    f.method = "POST"; f.action = BASE; f.target = "nx_msg2";
    for (const [k, v] of Object.entries({ stato_principale: "messenger", form_stato: "studente", current_user, current_key })) {
      const i = document.createElement("input"); i.type = "hidden"; i.name = k; i.value = v; f.appendChild(i);
    }
    document.body.appendChild(f);
    f.submit();
    let righe = [], ultimoN = -1, stabile = 0;
    const t0 = Date.now();
    await new Promise((res) => {
      const iv = setInterval(() => {
        try {
          const d = ifr.contentDocument;
          const r = d ? [...d.querySelectorAll("tr")].filter((tr) => tr.querySelectorAll("td").length >= 3 && /\d{2}\/\d{2}\/\d{4}/.test(tr.textContent)) : [];
          if (r.length && r.length === ultimoN) stabile++; else stabile = 0;
          ultimoN = r.length;
          righe = r.map((tr) => {
            const td = [...tr.querySelectorAll("td")].map((x) => pulisci(x.textContent));
            const data = (tr.textContent.match(/\d{2}\/\d{2}\/\d{4}/) || [""])[0];
            const k = data ? td.findIndex((t) => t.indexOf(data) >= 0 && t.length <= 14) : -1;
            if (k < 0) return null;
            const vuoto = (s) => !s || /^\d*$/.test(s);
            let iOgg = k - 1;
            while (iOgg > 0 && vuoto(td[iOgg])) iOgg--;
            let iMit = iOgg - 1;
            while (iMit > 0 && vuoto(td[iMit])) iMit--;
            const mittente = (td[iMit] || "").replace(/\s+\d+$/, "");
            const oggetto = td[iOgg] || "";
            if (!oggetto || /^oggetto$/i.test(oggetto) || /^da$/i.test(mittente)) return null;
            return { data, mittente, oggetto, stato: td[k + 1] || "" };
          }).filter(Boolean);
          if (stabile >= 2) { clearInterval(iv); res(); return; }
        } catch (_) {}
        if (Date.now() - t0 > 20000) { clearInterval(iv); res(); }
      }, 300);
    });
    let conteggi = null;
    try {
      const txt = pulisci(ifr.contentDocument ? ifr.contentDocument.body.textContent : "");
      const num = (re) => { const mm = txt.match(re); return mm ? +mm[1] : 0; };
      conteggi = {
        ricevuti: num(/In arrivo\s+(\d+)/),
        da_leggere: num(/Da leggere\s+(\d+)/),
        conferma_lettura: num(/Da confermare lettura\s+(\d+)/),
        circolare: num(/Circolari\s+(\d+)/),
      };
    } catch (_) {}
    ifr.remove(); f.remove();
    return { lista: righe.filter((m) => m.oggetto), conteggi };
  }

  async function getProfilo() {
    const { current_user, current_key } = leggiSessione();
    const f = new FormData();
    f.append("stato_principale", "messenger");
    f.append("form_stato", "studente");
    f.append("current_user", current_user);
    f.append("current_key", current_key);
    const r = await fetch(BASE, { method: "POST", credentials: "same-origin", body: f });
    const doc = new DOMParser().parseFromString(await r.text(), "text/html");
    doc.querySelectorAll("script,style").forEach((e) => e.remove());
    const m = pulisci(doc.body?.textContent).match(/☰\s*(.+?)\s+Messenger/);
    return { nome: m ? m[1] : "" };
  }

  async function esporta() {
    const [v, c, a, n, s, p, m] = await Promise.all([
      getVoti(), getCompiti(), getAgenda(),
      getNoteDisciplinari().catch(() => null), getAssenze().catch(() => null), getProfilo().catch(() => null),
      getMessaggi().catch(() => null),
    ]);
    return JSON.stringify({
      versione: 4, creato: new Date().toISOString(), medie: v.medie, voti: v.voti,
      compiti: c, agenda: a, note: n, assenze: s, profilo: p,
      messaggi: m && m.lista ? m.lista : (Array.isArray(m) ? m : null),
      messaggiConteggi: m && m.conteggi ? m.conteggi : null
    });
  }

  return { getProfilo, getVoti, getCompiti, getAgenda, esporta, getNoteDisciplinari, getAssenze, getMessaggi, diagnosi };
})();
