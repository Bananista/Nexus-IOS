# Quaderno iOS

Client iOS non ufficiale per il registro elettronico Mastercom, sviluppato in Swift/SwiftUI e WKWebView. Questa applicazione replica fedelmente l'architettura, il design (HTML/CSS), lo script JavaScript (`mastercom-reader.js`) e tutte le funzionalità dell'app Android originale `Quaderno`, con sincronizzazione Firebase integrata.

## Architettura del Progetto
- **UI & Design**: Utilizza la stessa interfaccia HTML/CSS (`quaderno.html`) ed esegue lo script `mastercom-reader.js` all'interno di un `WKWebView` locale.
- **Ponte nativo (`AppBridge`)**: Replica esattamente la classe `Ponte` di Kotlin, esponendo metodi JavaScript per login, salvataggio credenziali cifrate (Keychain), gestione notifiche e aggiornamento dati.
- **Database Firebase**: Configurato con il database in tempo reale Firebase per la sincronizzazione di classe, interrogazioni e riserve.
- **Persistenza & Database**: Salva la cache dei voti, compiti, note e preferenze in modo analogo alla versione Android (`UserDefaults` / Keychain).

## Struttura per GitHub Actions
I file sorgente e `Package.swift` si trovano direttamente nella radice per consentire a GitHub Actions di individuare e compilare il progetto Swift senza errori di percorsi o target sovrapposti.
