import Foundation
import Security

/// Credenziali Mastercom, custodite nel Keychain di iOS (cifrato dal sistema).
struct Credenziali: Codable, Equatable {
    var utente: String
    var password: String
}

enum Portachiavi {
    private static let servizio = "it.quaderno.registro.ios"
    private static let account = "mastercom"

    private static var base: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: servizio,
         kSecAttrAccount as String: account]
    }

    static func leggi() -> Credenziali? {
        var q = base
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let dati = out as? Data else { return nil }
        return try? JSONDecoder().decode(Credenziali.self, from: dati)
    }

    static func salva(_ c: Credenziali) {
        guard let dati = try? JSONEncoder().encode(c) else { return }
        SecItemDelete(base as CFDictionary)
        var q = base
        q[kSecValueData as String] = dati
        q[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        SecItemAdd(q as CFDictionary, nil)
    }

    static func elimina() {
        SecItemDelete(base as CFDictionary)
    }
}
