import SwiftUI
import WebKit
import UserNotifications
import BackgroundTasks

enum Risorse {
    static var bundle: Bundle {
        #if SWIFT_PACKAGE
        return Bundle.module
        #else
        return Bundle.main
        #endif
    }
}

/// Copia nativa del localStorage dell'interfaccia: sopravvive anche se iOS svuota la WebView.
final class ArchivioLocale {
    private var dati: [String: String]
    private let file: URL
    init() {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        file = dir.appendingPathComponent("localstorage.json")
        dati = (try? JSONDecoder().decode([String: String].self, from: Data(contentsOf: file))) ?? [:]
    }
    var tutto: [String: String] { dati }
    func imposta(_ k: String, _ v: String?) {
        if let v { dati[k] = v } else { dati.removeValue(forKey: k) }
        if let d = try? JSONEncoder().encode(dati) { try? d.write(to: file, options: .atomic) }
    }
}

/// Cuore dell'app: tiene insieme la WebView dell'interfaccia ("quaderno"),
/// quella di Mastercom, le credenziali, la sincronizzazione e le notifiche.
@MainActor
final class Motore: NSObject, ObservableObject {

    // MARK: - Costanti
    nonisolated static let indirizzoMastercom = URL(string: "https://marconi-fc.registroelettronico.com/mastercom/index.php")!
    nonisolated static let origineInterfaccia = URL(string: "https://appassets.nexus.local/quaderno.html")!
    private let categorie = ["voti", "compiti", "agenda", "avvisi", "note", "assenze"]

    // MARK: - Stato
    @Published var mostraMastercom = false
    let quaderno: WKWebView
    let mastercom: WKWebView

    private var credenziali: Credenziali? = Portachiavi.leggi()
    private var preferenzeNotifiche: [String: Bool] = [:]
    private var scriptInEsecuzione = false
    private var generazionePagina = 0
    private let archivio = ArchivioLocale()
    private var ultimoSuccesso = Date.distantPast
    nonisolated static let idRefresh = "it.quaderno.registro.ios.refresh"
    static weak var condiviso: Motore?
    private var invii = 0
    private var ultimoAggiornamento = Date.distantPast
    private var timer: Timer?
    private let memoria = UserDefaults.standard

    // MARK: - Avvio
    override init() {
        // WebView dell'interfaccia
        let cfgQ = WKWebViewConfiguration()
        let ucQ = WKUserContentController()
        cfgQ.userContentController = ucQ
        quaderno = WKWebView(frame: .zero, configuration: cfgQ)

        // WebView di Mastercom
        let cfgM = WKWebViewConfiguration()
        let ucM = WKUserContentController()
        cfgM.userContentController = ucM
        cfgM.websiteDataStore = .default()
        mastercom = WKWebView(frame: .zero, configuration: cfgM)

        super.init()

        let statoIniziale = Self.letteraleJS(["cred": credenziali != nil, "stato": ultimoStatoTesto()])
        ucQ.addUserScript(WKUserScript(source: Self.scriptArchivio(archivio.tutto),
                                       injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucQ.add(RicevitoreDebole(self), name: "ls")
        ucQ.addUserScript(WKUserScript(source: Self.scriptPonte(statoIniziale),
                                       injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucQ.add(RicevitoreDebole(self), name: "ponte")

        ucM.addUserScript(WKUserScript(source: Self.scriptLettore(),
                                       injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucM.addUserScript(WKUserScript(source: Self.scriptCattura,
                                       injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        ucM.add(RicevitoreDebole(self), name: "mc")

        for v in [quaderno, mastercom] {
            v.isOpaque = false
            v.backgroundColor = UIColor(red: 7/255, green: 10/255, blue: 22/255, alpha: 1)
            v.scrollView.backgroundColor = v.backgroundColor
            if #available(iOS 16.4, *) { v.isInspectable = true }
        }
        quaderno.scrollView.bounces = false
        quaderno.scrollView.contentInsetAdjustmentBehavior = .never
        quaderno.navigationDelegate = self
        mastercom.navigationDelegate = self
        mastercom.customUserAgent = nil

        Motore.condiviso = self
        caricaInterfaccia()
        if credenziali != nil { avviaSincronizzazione() }
        timer = Timer.scheduledTimer(withTimeInterval: 300, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.aggiornaSeServe(minimo: 240) }
        }
    }

    private func caricaInterfaccia() {
        let b = Risorse.bundle
        let url = b.url(forResource: "quaderno", withExtension: "html")
            ?? b.url(forResource: "quaderno", withExtension: "html", subdirectory: "Resources")
        guard let url, let html = try? String(contentsOf: url, encoding: .utf8) else {
            quaderno.loadHTMLString("<body style='background:#070a16;color:#fff;font:16px system-ui;padding:40px'>Risorsa quaderno.html mancante.</body>", baseURL: nil)
            return
        }
        quaderno.loadHTMLString(html, baseURL: Self.origineInterfaccia)
    }

    // MARK: - Controllo in background (best effort: iOS decide quando concederlo)
    func inBackground() { programmaRefresh() }

    func programmaRefresh() {
        guard credenziali != nil else { return }
        let r = BGAppRefreshTaskRequest(identifier: Self.idRefresh)
        r.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60)
        try? BGTaskScheduler.shared.submit(r)
    }

    func eseguiInBackground(_ task: BGAppRefreshTask) async {
        programmaRefresh()
        guard credenziali != nil else { task.setTaskCompleted(success: true); return }
        var scaduto = false
        task.expirationHandler = { scaduto = true }
        let inizio = Date()
        avviaSincronizzazione()
        while !scaduto, ultimoSuccesso < inizio, Date().timeIntervalSince(inizio) < 25 {
            try? await Task.sleep(nanoseconds: 1_000_000_000)
        }
        task.setTaskCompleted(success: ultimoSuccesso >= inizio)
    }

    func tornatoInPrimoPiano() { aggiornaSeServe(minimo: 60) }

    private func aggiornaSeServe(minimo: TimeInterval) {
        guard credenziali != nil, Date().timeIntervalSince(ultimoAggiornamento) > minimo else { return }
        avviaSincronizzazione()
    }

    // MARK: - Sincronizzazione con Mastercom
    private func avviaSincronizzazione() {
        ultimoAggiornamento = Date()
        invii = 0
        mastercom.load(URLRequest(url: Self.indirizzoMastercom))
    }

    /// Eseguito a ogni caricamento di pagina di Mastercom.
    private func elaboraPaginaMastercom() async {
        guard !scriptInEsecuzione else { return }
        scriptInEsecuzione = true
        defer { scriptInEsecuzione = false }
        let cred: Any = credenziali.map { ["u": $0.utente, "p": $0.password] } ?? NSNull()
        do {
            let r = try await mastercom.callAsyncJavaScript(Self.scriptSincronizzazione,
                                                            arguments: ["cred": cred],
                                                            in: nil, contentWorld: .page)
            guard let d = r as? [String: Any], let esito = d["s"] as? String else { return }
            switch esito {
            case "inviato":
                invii += 1
                if invii >= 3 {
                    invii = 0
                    await chiamaInterfaccia("Quaderno.serveLogin(true)")
                } else {
                    // Se la pagina non si ricarica da sola, riprova dopo qualche secondo.
                    let g = generazionePagina
                    Task { [weak self] in
                        try? await Task.sleep(nanoseconds: 7_000_000_000)
                        guard let self, self.generazionePagina == g else { return }
                        await self.elaboraPaginaMastercom()
                    }
                }
            case "login":
                let dopoTentativo = invii > 0
                invii = 0
                await chiamaInterfaccia("Quaderno.serveLogin(\(dopoTentativo))")
            case "dati":
                invii = 0
                if let json = d["json"] as? String { await consegnaDati(json) }
            default: break
            }
        } catch {
            await chiamaInterfaccia("Quaderno.errore(m)", ["m": error.localizedDescription])
        }
    }

    private func consegnaDati(_ json: String) async {
        await chiamaInterfaccia("try{Quaderno.importa(j);Quaderno.entra()}catch(e){Quaderno.errore(String(e))}",
                                ["j": json])
        ultimoSuccesso = Date()
        confrontaENotifica(json)
        aggiornaStatoNellInterfaccia()
    }

    private func chiamaInterfaccia(_ js: String, _ args: [String: Any] = [:]) async {
        _ = try? await quaderno.callAsyncJavaScript(js, arguments: args, in: nil, contentWorld: .page)
    }

    // MARK: - Ponte (UI -> nativo)
    private func gestisciPonte(_ nome: String, _ a: [Any]) {
        switch nome {
        case "accedi":
            guard a.count == 2, let u = a[0] as? String, let p = a[1] as? String else { return }
            let c = Credenziali(utente: u.trimmingCharacters(in: .whitespaces), password: p)
            credenziali = c
            Portachiavi.salva(c)
            aggiornaStatoNellInterfaccia()
            pulisciSessioneMastercom { self.avviaSincronizzazione() }
        case "esci":
            credenziali = nil
            Portachiavi.elimina()
            memoria.removeObject(forKey: "nx.prec")
            memoria.removeObject(forKey: "nx.ultimo")
            pulisciSessioneMastercom { self.mastercom.loadHTMLString("", baseURL: nil) }
            aggiornaStatoNellInterfaccia()
        case "aggiornaOra":
            if credenziali != nil { avviaSincronizzazione() }
        case "impostaNotifiche":
            if let s = a.first as? String,
               let o = try? JSONSerialization.jsonObject(with: Data(s.utf8)) as? [String: Any] {
                preferenzeNotifiche = o.compactMapValues { ($0 as? Bool) ?? (($0 as? NSNumber)?.boolValue) }
                richiediPermessoNotifiche()
            }
        case "provaNotifica":
            richiediPermessoNotifiche { self.invia(titolo: "Nexus", testo: "Le notifiche funzionano.") }
        case "mostraMastercom":
            mostraMastercom = true
        default: break
        }
    }

    private func pulisciSessioneMastercom(_ dopo: @escaping () -> Void) {
        let store = mastercom.configuration.websiteDataStore
        store.fetchDataRecords(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes()) { record in
            let mie = record.filter { $0.displayName.contains("registroelettronico") }
            store.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), for: mie) {
                DispatchQueue.main.async(execute: dopo)
            }
        }
    }

    // MARK: - Stato mostrato nelle impostazioni
    private func ultimoStatoTesto() -> String {
        guard let d = memoria.object(forKey: "nx.ultimo") as? Date else { return "" }
        let f = DateFormatter(); f.locale = Locale(identifier: "it_IT")
        f.dateFormat = "d MMM, HH:mm"
        return f.string(from: d)
    }

    private func aggiornaStatoNellInterfaccia() {
        memoria.set(Date(), forKey: "nx.ultimo")
        let stato: [String: Any] = ["cred": credenziali != nil, "stato": ultimoStatoTesto()]
        Task { await chiamaInterfaccia("window.__ponteStato = s", ["s": stato]) }
    }

    // MARK: - Notifiche locali
    private func richiediPermessoNotifiche(_ dopo: (() -> Void)? = nil) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { ok, _ in
            if ok, let dopo { DispatchQueue.main.async(execute: dopo) }
        }
    }

    private func invia(titolo: String, testo: String) {
        let c = UNMutableNotificationContent()
        c.title = titolo; c.body = testo; c.sound = .default
        let r = UNNotificationRequest(identifier: UUID().uuidString, content: c, trigger: nil)
        UNUserNotificationCenter.current().add(r)
    }

    private func attiva(_ k: String) -> Bool { preferenzeNotifiche[k] ?? true }

    private static func conta(_ v: Any?) -> Int {
        if let a = v as? [Any] { return a.count }
        if let d = v as? [String: Any] { return d.values.reduce(0) { $0 + conta($1) } }
        return 0
    }

    /// Confronta con l'ultima sincronizzazione e avvisa delle novità.
    private func confrontaENotifica(_ json: String) {
        guard let o = try? JSONSerialization.jsonObject(with: Data(json.utf8)) as? [String: Any] else { return }
        var ora: [String: Int] = [
            "voti": Self.conta(o["voti"]), "agenda": Self.conta(o["agenda"]),
            "avvisi": Self.conta(o["messaggi"]), "note": Self.conta(o["note"]),
            "assenze": Self.conta(o["assenze"])
        ]
        let compitiAperti = ((o["compiti"] as? [[String: Any]]) ?? [])
            .compactMap { $0["id"] as? String }
        ora["compiti"] = compitiAperti.count
        let idsPrima = Set(memoria.stringArray(forKey: "nx.compiti") ?? [])
        memoria.set(compitiAperti, forKey: "nx.compiti")

        guard let prima = memoria.dictionary(forKey: "nx.prec") as? [String: Int] else {
            memoria.set(ora, forKey: "nx.prec"); return   // primo avvio: nessun avviso
        }
        memoria.set(ora, forKey: "nx.prec")

        let testi: [String: (String, String)] = [
            "voti": ("Nuovo voto", "Hai un nuovo voto su Mastercom."),
            "compiti": ("Nuovo compito", "Sono stati assegnati nuovi compiti."),
            "agenda": ("Novità in agenda", "C'è una novità in agenda."),
            "avvisi": ("Nuova comunicazione", "Hai una nuova comunicazione."),
            "note": ("Nuova nota", "È arrivata una nuova nota."),
            "assenze": ("Novità sulle assenze", "Controlla le tue assenze.")
        ]
        for k in categorie where attiva(k) {
            let nuovo: Bool = (k == "compiti")
                ? !Set(compitiAperti).subtracting(idsPrima).isEmpty
                : (ora[k] ?? 0) > (prima[k] ?? 0)
            if nuovo, let t = testi[k] { invia(titolo: t.0, testo: t.1) }
        }
    }
}

// MARK: - Messaggi dalle pagine web
extension Motore: WKScriptMessageHandler {
    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
        if m.name == "ls", let d = m.body as? [String: Any], let k = d["k"] as? String {
            archivio.imposta(k, d["v"] as? String)
        } else if m.name == "ponte", let d = m.body as? [String: Any], let metodo = d["m"] as? String {
            gestisciPonte(metodo, (d["a"] as? [Any]) ?? [])
        } else if m.name == "mc", let d = m.body as? [String: String],
                  let u = d["u"], let p = d["p"], !u.isEmpty, !p.isEmpty {
            // Accesso fatto a mano nella pagina Mastercom: ricordalo.
            let c = Credenziali(utente: u, password: p)
            if c != credenziali { credenziali = c; Portachiavi.salva(c); aggiornaStatoNellInterfaccia() }
        }
    }
}

// MARK: - Navigazione
extension Motore: WKNavigationDelegate {
    func webView(_ w: WKWebView, didFinish n: WKNavigation!) {
        guard w === mastercom, w.url?.host?.contains("registroelettronico") == true else { return }
        generazionePagina += 1
        Task { await elaboraPaginaMastercom() }
    }

    func webView(_ w: WKWebView, decidePolicyFor a: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        // Nell'interfaccia, i link esterni si aprono in Safari.
        if a.navigationType == .linkActivated, let url = a.request.url,
           url.host != Motore.origineInterfaccia.host, w.url?.host == Motore.origineInterfaccia.host {
            UIApplication.shared.open(url)
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }
}

// MARK: - Script JavaScript
extension Motore {
    static func letteraleJS(_ v: Any) -> String {
        guard let d = try? JSONSerialization.data(withJSONObject: v, options: [.fragmentsAllowed]),
              let s = String(data: d, encoding: .utf8) else { return "null" }
        return s
    }

    /// Ripristina e inoltra al nativo ogni modifica del localStorage.
    static func scriptArchivio(_ snap: [String: String]) -> String {
        """
        (function(){
          var snap = \(letteraleJS(snap));
          try { for (var k in snap) if (localStorage.getItem(k) === null) localStorage.setItem(k, snap[k]); } catch(e){}
          var S = Storage.prototype, si = S.setItem, ri = S.removeItem;
          function post(k, v){ try { window.webkit.messageHandlers.ls.postMessage({k: k, v: v}); } catch(e){} }
          S.setItem = function(k, v){ si.apply(this, arguments); if (this === window.localStorage) post(String(k), String(v)); };
          S.removeItem = function(k){ ri.apply(this, arguments); if (this === window.localStorage) post(String(k), null); };
        })();
        """
    }

    /// Oggetto `Ponte`: stessa interfaccia che l'UI usava su Android.
    static func scriptPonte(_ statoIniziale: String) -> String {
        """
        (function(){
          window.__ponteStato = \(statoIniziale);
          function invia(m, a){ window.webkit.messageHandlers.ponte.postMessage({m: m, a: a || []}); }
          window.Ponte = {
            haCredenziali: function(){ return !!(window.__ponteStato && window.__ponteStato.cred); },
            statoControllo: function(){ return (window.__ponteStato && window.__ponteStato.stato) || ""; },
            accedi: function(u, p){ invia('accedi', [u, p]); },
            esci: function(){ invia('esci'); },
            aggiornaOra: function(){ invia('aggiornaOra'); },
            impostaNotifiche: function(j){ invia('impostaNotifiche', [j]); },
            provaNotifica: function(){ invia('provaNotifica'); },
            mostraMastercom: function(){ invia('mostraMastercom'); }
          };
        })();
        """
    }

    /// Carica il lettore dei dati dentro la pagina di Mastercom.
    static func scriptLettore() -> String {
        let b = Risorse.bundle
        let url = b.url(forResource: "mastercom-reader", withExtension: "js")
            ?? b.url(forResource: "mastercom-reader", withExtension: "js", subdirectory: "Resources")
        let sorgente = url.flatMap { try? String(contentsOf: $0, encoding: .utf8) } ?? ""
        return "(function(){ if (window.MastercomReader) return; \(sorgente)\n window.MastercomReader = MastercomReader; })();"
    }

    /// Memorizza utente e password se la persona accede a mano.
    static let scriptCattura = """
    (function(){
      var p = document.querySelector('input[type=password]');
      if (!p) return;
      function salva(){
        var campi = Array.prototype.filter.call(document.querySelectorAll('input'), function(i){
          return /^(text|email|tel|number|)$/i.test(i.type) && (p.compareDocumentPosition(i) & 2);
        });
        var u = campi[campi.length - 1];
        if (u && u.value && p.value)
          window.webkit.messageHandlers.mc.postMessage({u: u.value, p: p.value});
      }
      document.addEventListener('click', salva, true);
      document.addEventListener('submit', salva, true);
      document.addEventListener('keydown', function(e){ if (e.key === 'Enter') salva(); }, true);
    })();
    """

    /// Corpo di funzione asincrona: accede se serve, poi esporta i dati.
    static let scriptSincronizzazione = """
    const p = document.querySelector('input[type=password]');
    if (p && p.offsetParent !== null) {
      if (!cred) return { s: 'login' };
      const campi = Array.prototype.filter.call(document.querySelectorAll('input'), function(i){
        return i.offsetParent !== null && /^(text|email|tel|number|)$/i.test(i.type) && (p.compareDocumentPosition(i) & 2);
      });
      const u = campi[campi.length - 1];
      if (!u) return { s: 'login' };
      const imposta = function(el, v){
        el.focus(); el.value = v;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      };
      imposta(u, cred.u); imposta(p, cred.p);
      const f = p.form;
      let b = f && f.querySelector('button[type=submit],input[type=submit]');
      if (!b) b = Array.prototype.find.call(document.querySelectorAll('button,input[type=button],input[type=submit],a'), function(e){
        return /accedi|entra|login|invia/i.test((e.value || '') + ' ' + e.textContent);
      });
      if (b) b.click(); else if (f) f.submit();
      return { s: 'inviato' };
    }
    let ok = false;
    for (let i = 0; i < 40 && !ok; i++) {
      if (window.MastercomReader) {
        const d = MastercomReader.diagnosi();
        ok = d.current_user && d.current_key;
      }
      if (!ok) await new Promise(function(r){ setTimeout(r, 500); });
    }
    if (!ok) return { s: 'login' };
    return { s: 'dati', json: await MastercomReader.esporta() };
    """
}
