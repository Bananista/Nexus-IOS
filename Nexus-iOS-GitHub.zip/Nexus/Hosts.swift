import SwiftUI
import WebKit

/// Contenitore SwiftUI per la WebView dell'interfaccia.
struct QuadernoHost: UIViewRepresentable {
    let motore: Motore
    func makeUIView(context: Context) -> WKWebView { motore.quaderno }
    func updateUIView(_ vista: WKWebView, context: Context) {}
}

/// Contenitore SwiftUI per la WebView di Mastercom.
struct MastercomHost: UIViewRepresentable {
    let motore: Motore
    func makeUIView(context: Context) -> WKWebView { motore.mastercom }
    func updateUIView(_ vista: WKWebView, context: Context) {}
}

/// Evita il ciclo di riferimenti tra WKUserContentController e il motore.
final class RicevitoreDebole: NSObject, WKScriptMessageHandler {
    private weak var bersaglio: WKScriptMessageHandler?
    init(_ b: WKScriptMessageHandler) { bersaglio = b }
    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
        bersaglio?.userContentController(c, didReceive: m)
    }
}
