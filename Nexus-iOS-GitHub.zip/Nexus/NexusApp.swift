import SwiftUI
import BackgroundTasks

final class Delegato: NSObject, UIApplicationDelegate {
    func application(_ a: UIApplication,
                     didFinishLaunchingWithOptions o: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: Motore.idRefresh, using: nil) { task in
            Task { @MainActor in
                if let m = Motore.condiviso, let t = task as? BGAppRefreshTask {
                    await m.eseguiInBackground(t)
                } else {
                    task.setTaskCompleted(success: false)
                }
            }
        }
        return true
    }
}

@main
struct NexusApp: App {
    @UIApplicationDelegateAdaptor(Delegato.self) private var delegato
    @StateObject private var motore = Motore()
    @Environment(\.scenePhase) private var fase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(motore)
                .preferredColorScheme(.dark)
                .onChange(of: fase) { nuova in
                    if nuova == .active { motore.tornatoInPrimoPiano() }
                    if nuova == .background { motore.inBackground() }
                }
        }
    }
}

struct RootView: View {
    @EnvironmentObject var motore: Motore
    private let sfondo = Color(red: 7/255, green: 10/255, blue: 22/255)

    var body: some View {
        ZStack {
            sfondo.ignoresSafeArea()
            // Pagina Mastercom: sempre nella gerarchia a dimensione piena (quasi invisibile)
            // cosi' iOS non la sospende e il layout e' quello di un vero telefono.
            MastercomHost(motore: motore)
                .opacity(motore.mostraMastercom ? 1 : 0.01)
                .allowsHitTesting(motore.mostraMastercom)
                .zIndex(motore.mostraMastercom ? 2 : 0)
            // Interfaccia "quaderno"
            QuadernoHost(motore: motore)
                .ignoresSafeArea()
                .zIndex(1)
            if motore.mostraMastercom {
                VStack {
                    HStack {
                        Spacer()
                        Button("Chiudi") { motore.mostraMastercom = false }
                            .font(.headline)
                            .padding(.horizontal, 16).padding(.vertical, 8)
                            .background(.ultraThinMaterial, in: Capsule())
                    }
                    Spacer()
                }
                .padding()
                .zIndex(3)
            }
        }
    }
}
